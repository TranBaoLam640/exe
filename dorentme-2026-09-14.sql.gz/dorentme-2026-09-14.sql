-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: dorentme
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `dorentme`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `dorentme` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `dorentme`;

--
-- Table structure for table `Brands`
--

DROP TABLE IF EXISTS `Brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Brands` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Slug` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Brands_Name` (`Name`),
  UNIQUE KEY `IX_Brands_Slug` (`Slug`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Brands`
--

LOCK TABLES `Brands` WRITE;
/*!40000 ALTER TABLE `Brands` DISABLE KEYS */;
INSERT INTO `Brands` VALUES (1,'SÓ VINTAGE','so-vintage',1,'2026-09-08 14:07:26.000000',NULL),(2,'D.CHIC','d-chic',1,'2026-09-08 14:07:26.000000',NULL),(3,'FLANE','flane',1,'2026-09-08 14:07:26.000000',NULL),(4,'LANE JT','lane-jt',1,'2026-09-08 14:07:26.000000',NULL),(5,'HƯƠNG BOUTIQUE','huong-boutique',1,'2026-09-08 14:07:26.000000',NULL),(6,'CHIRON','chiron',1,'2026-09-08 14:07:26.000000',NULL),(7,'JOLIE LOFT','jolie-loft',1,'2026-09-08 14:07:26.000000',NULL),(8,'MAISON LONG','maison-long',1,'2026-09-08 14:07:26.000000',NULL),(9,'Mys.P','mys-p',1,'2026-09-08 14:07:26.000000',NULL),(10,'KYCÉ','kyce',1,'2026-09-08 14:07:26.000000',NULL),(11,'Manichini','manichini',1,'2026-09-08 14:07:26.000000',NULL),(12,'ONONMADE','ononmade',1,'2026-09-08 14:07:26.000000',NULL),(13,'JENNIE CHOO','jennie-choo',1,'2026-09-08 14:07:26.000000',NULL),(14,'AMELIÉE','ameliee',1,'2026-09-08 14:07:26.000000',NULL),(15,'CHOUCHOU','chouchou',1,'2026-09-08 14:07:26.000000',NULL),(16,'Bliss Shop','bliss-shop',1,'2026-09-08 14:07:26.000000',NULL),(17,'Other','other',1,'2026-09-08 14:07:26.000000',NULL),(18,'Khác','khac',1,'2026-09-09 15:47:49.000000',NULL),(19,'Mainichi','mainichi',1,'2026-09-09 15:47:49.000000',NULL);
/*!40000 ALTER TABLE `Brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CartItems`
--

DROP TABLE IF EXISTS `CartItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `CartItems` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `CartId` int NOT NULL,
  `ProductVariantId` int NOT NULL,
  `Quantity` int NOT NULL,
  `RentalStartDate` date NOT NULL,
  `RentalEndDate` date NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_CartItems_CartId_ProductVariantId_RentalStartDate_RentalEndD~` (`CartId`,`ProductVariantId`,`RentalStartDate`,`RentalEndDate`),
  KEY `IX_CartItems_CartId` (`CartId`),
  KEY `IX_CartItems_ProductVariantId` (`ProductVariantId`),
  CONSTRAINT `FK_CartItems_Carts_CartId` FOREIGN KEY (`CartId`) REFERENCES `Carts` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_CartItems_ProductVariants_ProductVariantId` FOREIGN KEY (`ProductVariantId`) REFERENCES `ProductVariants` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_CartItems_DateRange` CHECK ((`RentalEndDate` > `RentalStartDate`)),
  CONSTRAINT `CK_CartItems_Quantity` CHECK ((`Quantity` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CartItems`
--

LOCK TABLES `CartItems` WRITE;
/*!40000 ALTER TABLE `CartItems` DISABLE KEYS */;
/*!40000 ALTER TABLE `CartItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Carts`
--

DROP TABLE IF EXISTS `Carts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Carts` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int DEFAULT NULL,
  `SessionId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  `ActiveSessionId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci GENERATED ALWAYS AS ((case when (`Status` = _utf8mb4'active') then `SessionId` else NULL end)) STORED,
  `ActiveUserId` int GENERATED ALWAYS AS ((case when (`Status` = _utf8mb4'active') then `UserId` else NULL end)) STORED,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UX_Carts_Active_Session` (`ActiveSessionId`),
  UNIQUE KEY `UX_Carts_Active_User` (`ActiveUserId`),
  KEY `IX_Carts_SessionId` (`SessionId`),
  KEY `IX_Carts_UserId` (`UserId`),
  CONSTRAINT `FK_Carts_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_Carts_Status` CHECK ((`Status` in (_utf8mb4'active',_utf8mb4'ordered',_utf8mb4'abandoned'))),
  CONSTRAINT `CK_Carts_UserOrSession` CHECK (((`UserId` is not null) or (`SessionId` is not null)))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Carts`
--

LOCK TABLES `Carts` WRITE;
/*!40000 ALTER TABLE `Carts` DISABLE KEYS */;
INSERT INTO `Carts` (`Id`, `UserId`, `SessionId`, `Status`, `CreatedAt`, `UpdatedAt`) VALUES (1,11,NULL,'active','2026-09-10 03:34:27.556775','2026-09-10 03:36:31.261247'),(2,12,NULL,'active','2026-09-11 01:45:45.834520',NULL);
/*!40000 ALTER TABLE `Carts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Categories`
--

DROP TABLE IF EXISTS `Categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Categories` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Slug` varchar(120) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Categories_Name` (`Name`),
  UNIQUE KEY `IX_Categories_Slug` (`Slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Categories`
--

LOCK TABLES `Categories` WRITE;
/*!40000 ALTER TABLE `Categories` DISABLE KEYS */;
INSERT INTO `Categories` VALUES (1,'Áo dài','ao-dai',1,'2026-09-08 15:30:55.000000',NULL),(2,'Váy đi biển','vay-di-bien',1,'2026-09-08 15:30:55.000000',NULL),(3,'Váy dự tiệc','vay-du-tiec',1,'2026-09-08 15:30:55.000000',NULL),(4,'Phụ kiện','phu-kien',1,'2026-09-08 15:30:55.000000',NULL),(5,'Váy lụa','vay-lua',1,'2026-09-08 15:30:55.000000',NULL),(6,'Thanh lý','thanh-ly',1,'2026-09-08 15:30:55.000000',NULL);
/*!40000 ALTER TABLE `Categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatMessages`
--

DROP TABLE IF EXISTS `ChatMessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ChatMessages` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ChatSessionId` int NOT NULL,
  `Role` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_ChatMessages_ChatSessionId_CreatedAt` (`ChatSessionId`,`CreatedAt`),
  CONSTRAINT `FK_ChatMessages_ChatSessions_ChatSessionId` FOREIGN KEY (`ChatSessionId`) REFERENCES `ChatSessions` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_ChatMessages_Role` CHECK ((`Role` in (_utf8mb4'user',_utf8mb4'model',_utf8mb4'system')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatMessages`
--

LOCK TABLES `ChatMessages` WRITE;
/*!40000 ALTER TABLE `ChatMessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChatMessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ChatSessions`
--

DROP TABLE IF EXISTS `ChatSessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ChatSessions` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int DEFAULT NULL,
  `SessionId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_ChatSessions_SessionId` (`SessionId`),
  KEY `IX_ChatSessions_UserId` (`UserId`),
  CONSTRAINT `FK_ChatSessions_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ChatSessions`
--

LOCK TABLES `ChatSessions` WRITE;
/*!40000 ALTER TABLE `ChatSessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ChatSessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ContactMessages`
--

DROP TABLE IF EXISTS `ContactMessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ContactMessages` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Subject` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_ContactMessages_Status` (`Status`),
  CONSTRAINT `CK_ContactMessages_Status` CHECK ((`Status` in (_utf8mb4'new',_utf8mb4'read',_utf8mb4'replied',_utf8mb4'closed')))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ContactMessages`
--

LOCK TABLES `ContactMessages` WRITE;
/*!40000 ALTER TABLE `ContactMessages` DISABLE KEYS */;
INSERT INTO `ContactMessages` VALUES (1,'con cho quanh','quanhngu@gmail.com','6969696969',NULL,'dmquanh','new','2026-09-02 15:23:49.895435',NULL),(2,'Trần Bảo Lâm','lamtranbao1234@gmail.com','0985308617',NULL,'tôi bị ngu','new','2026-09-02 15:37:02.752949',NULL);
/*!40000 ALTER TABLE `ContactMessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LoyaltyTransactions`
--

DROP TABLE IF EXISTS `LoyaltyTransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LoyaltyTransactions` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `OrderId` int DEFAULT NULL,
  `Points` int NOT NULL,
  `Type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Note` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_LoyaltyTransactions_OrderId` (`OrderId`),
  KEY `IX_LoyaltyTransactions_UserId_CreatedAt` (`UserId`,`CreatedAt`),
  CONSTRAINT `FK_LoyaltyTransactions_Orders_OrderId` FOREIGN KEY (`OrderId`) REFERENCES `Orders` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_LoyaltyTransactions_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_LoyaltyTransactions_Type` CHECK ((`Type` in (_utf8mb4'earn',_utf8mb4'redeem',_utf8mb4'adjust')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LoyaltyTransactions`
--

LOCK TABLES `LoyaltyTransactions` WRITE;
/*!40000 ALTER TABLE `LoyaltyTransactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `LoyaltyTransactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NewsArticles`
--

DROP TABLE IF EXISTS `NewsArticles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `NewsArticles` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `AuthorId` int DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Description` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `ImageUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `PublishedAt` datetime(6) DEFAULT NULL,
  `IsPublished` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_NewsArticles_Slug` (`Slug`),
  KEY `IX_NewsArticles_AuthorId` (`AuthorId`),
  KEY `IX_NewsArticles_IsPublished` (`IsPublished`),
  KEY `IX_NewsArticles_PublishedAt` (`PublishedAt`),
  CONSTRAINT `FK_NewsArticles_Users_AuthorId` FOREIGN KEY (`AuthorId`) REFERENCES `Users` (`Id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NewsArticles`
--

LOCK TABLES `NewsArticles` WRITE;
/*!40000 ALTER TABLE `NewsArticles` DISABLE KEYS */;
/*!40000 ALTER TABLE `NewsArticles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Notifications`
--

DROP TABLE IF EXISTS `Notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Notifications` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `Type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Message` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `RelatedType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `RelatedId` int DEFAULT NULL,
  `IsRead` tinyint(1) NOT NULL,
  `ReadAt` datetime(6) DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Notifications_Type` (`Type`),
  KEY `IX_Notifications_UserId` (`UserId`),
  KEY `IX_Notifications_UserId_IsRead` (`UserId`,`IsRead`),
  CONSTRAINT `FK_Notifications_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_Notifications_Type` CHECK ((`Type` in (_utf8mb4'order',_utf8mb4'payment',_utf8mb4'shipping',_utf8mb4'refund',_utf8mb4'voucher',_utf8mb4'system',_utf8mb4'tryon')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Notifications`
--

LOCK TABLES `Notifications` WRITE;
/*!40000 ALTER TABLE `Notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `Notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderItems`
--

DROP TABLE IF EXISTS `OrderItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OrderItems` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `OrderId` int NOT NULL,
  `ProductId` int NOT NULL,
  `ProductVariantId` int NOT NULL,
  `ProductNameSnapshot` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `SizeSnapshot` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ColorSnapshot` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Quantity` int NOT NULL,
  `PricePerItem` decimal(18,2) NOT NULL,
  `DepositPerItem` decimal(18,2) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `DepositSubtotal` decimal(18,2) NOT NULL DEFAULT '0.00',
  `LineSubtotal` decimal(18,2) NOT NULL DEFAULT '0.00',
  `RentalDays` int NOT NULL DEFAULT '1',
  `RentalEndDate` date NOT NULL DEFAULT '2026-01-02',
  `RentalStartDate` date NOT NULL DEFAULT '2026-01-01',
  PRIMARY KEY (`Id`),
  KEY `IX_OrderItems_OrderId` (`OrderId`),
  KEY `IX_OrderItems_ProductId` (`ProductId`),
  KEY `IX_OrderItems_ProductVariantId` (`ProductVariantId`),
  KEY `IX_OrderItems_ProductVariantId_RentalStartDate_RentalEndDate` (`ProductVariantId`,`RentalStartDate`,`RentalEndDate`),
  CONSTRAINT `FK_OrderItems_Orders_OrderId` FOREIGN KEY (`OrderId`) REFERENCES `Orders` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_OrderItems_Products_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_OrderItems_ProductVariants_ProductVariantId` FOREIGN KEY (`ProductVariantId`) REFERENCES `ProductVariants` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_OrderItems_DateRange` CHECK ((`RentalEndDate` > `RentalStartDate`)),
  CONSTRAINT `CK_OrderItems_DepositPerItem` CHECK ((`DepositPerItem` >= 0)),
  CONSTRAINT `CK_OrderItems_DepositSubtotal` CHECK ((`DepositSubtotal` >= 0)),
  CONSTRAINT `CK_OrderItems_LineSubtotal` CHECK ((`LineSubtotal` >= 0)),
  CONSTRAINT `CK_OrderItems_PricePerItem` CHECK ((`PricePerItem` >= 0)),
  CONSTRAINT `CK_OrderItems_Quantity` CHECK ((`Quantity` > 0)),
  CONSTRAINT `CK_OrderItems_RentalDays` CHECK ((`RentalDays` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrderItems`
--

LOCK TABLES `OrderItems` WRITE;
/*!40000 ALTER TABLE `OrderItems` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrderItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderStatusHistory`
--

DROP TABLE IF EXISTS `OrderStatusHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OrderStatusHistory` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `OrderId` int NOT NULL,
  `OldStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `NewStatus` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Note` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CreatedByUserId` int DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_OrderStatusHistory_CreatedByUserId` (`CreatedByUserId`),
  KEY `IX_OrderStatusHistory_OrderId` (`OrderId`),
  KEY `IX_OrderStatusHistory_OrderId_CreatedAt` (`OrderId`,`CreatedAt`),
  CONSTRAINT `FK_OrderStatusHistory_Orders_OrderId` FOREIGN KEY (`OrderId`) REFERENCES `Orders` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_OrderStatusHistory_Users_CreatedByUserId` FOREIGN KEY (`CreatedByUserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrderStatusHistory`
--

LOCK TABLES `OrderStatusHistory` WRITE;
/*!40000 ALTER TABLE `OrderStatusHistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `OrderStatusHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Orders` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ShopId` int DEFAULT NULL,
  `OrderCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `UserId` int DEFAULT NULL,
  `CustomerName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CustomerPhone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CustomerEmail` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ShippingAddress` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CustomerNote` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TotalRent` decimal(18,2) NOT NULL,
  `TotalDeposit` decimal(18,2) NOT NULL,
  `TotalDiscount` decimal(18,2) NOT NULL,
  `TotalAmount` decimal(18,2) GENERATED ALWAYS AS (((`TotalRent` + `TotalDeposit`) - `TotalDiscount`)) STORED,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `DeliveryConfirmed` tinyint(1) NOT NULL,
  `ReturnRequestedAt` datetime(6) DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Orders_OrderCode` (`OrderCode`),
  KEY `IX_Orders_CreatedAt` (`CreatedAt`),
  KEY `IX_Orders_ShopId` (`ShopId`),
  KEY `IX_Orders_Status` (`Status`),
  KEY `IX_Orders_UserId` (`UserId`),
  CONSTRAINT `FK_Orders_Shops_ShopId` FOREIGN KEY (`ShopId`) REFERENCES `Shops` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Orders_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_Orders_DateRange` CHECK ((`EndDate` > `StartDate`)),
  CONSTRAINT `CK_Orders_Status` CHECK ((`Status` in (_utf8mb4'pending_confirmation',_utf8mb4'shipping',_utf8mb4'delivered',_utf8mb4'return_requested',_utf8mb4'return_processing',_utf8mb4'returned',_utf8mb4'cancelled'))),
  CONSTRAINT `CK_Orders_TotalDeposit` CHECK ((`TotalDeposit` >= 0)),
  CONSTRAINT `CK_Orders_TotalDiscount` CHECK ((`TotalDiscount` >= 0)),
  CONSTRAINT `CK_Orders_TotalRent` CHECK ((`TotalRent` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Orders`
--

LOCK TABLES `Orders` WRITE;
/*!40000 ALTER TABLE `Orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `Orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Payments`
--

DROP TABLE IF EXISTS `Payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Payments` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `OrderId` int NOT NULL,
  `Method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Amount` decimal(18,2) NOT NULL,
  `BankName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountNo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `TransferContent` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `TransactionCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ProviderTransactionId` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `PaidAt` datetime(6) DEFAULT NULL,
  `ConfirmedByUserId` int DEFAULT NULL,
  `ConfirmedAt` datetime(6) DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Payments_ProviderTransactionId` (`ProviderTransactionId`),
  KEY `IX_Payments_ConfirmedByUserId` (`ConfirmedByUserId`),
  KEY `IX_Payments_OrderId` (`OrderId`),
  KEY `IX_Payments_Status` (`Status`),
  KEY `IX_Payments_TransactionCode` (`TransactionCode`),
  CONSTRAINT `FK_Payments_Orders_OrderId` FOREIGN KEY (`OrderId`) REFERENCES `Orders` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Payments_Users_ConfirmedByUserId` FOREIGN KEY (`ConfirmedByUserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_Payments_Amount` CHECK ((`Amount` >= 0)),
  CONSTRAINT `CK_Payments_Status` CHECK ((`Status` in (_utf8mb4'pending',_utf8mb4'paid',_utf8mb4'failed',_utf8mb4'refunded',_utf8mb4'cancelled')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Payments`
--

LOCK TABLES `Payments` WRITE;
/*!40000 ALTER TABLE `Payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `Payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductCategories`
--

DROP TABLE IF EXISTS `ProductCategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductCategories` (
  `ProductId` int NOT NULL,
  `CategoryId` int NOT NULL,
  PRIMARY KEY (`ProductId`,`CategoryId`),
  KEY `IX_ProductCategories_CategoryId` (`CategoryId`),
  CONSTRAINT `FK_ProductCategories_Categories_CategoryId` FOREIGN KEY (`CategoryId`) REFERENCES `Categories` (`Id`) ON DELETE CASCADE,
  CONSTRAINT `FK_ProductCategories_Products_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductCategories`
--

LOCK TABLES `ProductCategories` WRITE;
/*!40000 ALTER TABLE `ProductCategories` DISABLE KEYS */;
INSERT INTO `ProductCategories` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(23,2),(24,2),(25,2),(26,2),(27,2),(28,3),(29,3),(30,3),(31,3),(32,3),(33,3),(34,3),(35,3),(36,3),(37,3),(38,3),(39,3),(40,3),(41,3),(42,3),(43,3),(44,4),(45,4),(46,4),(47,4),(48,4),(49,4),(50,4),(51,5),(52,5),(53,5),(54,5);
/*!40000 ALTER TABLE `ProductCategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductImages`
--

DROP TABLE IF EXISTS `ProductImages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductImages` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ProductId` int NOT NULL,
  `ImageUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `IsPrimary` tinyint(1) NOT NULL,
  `SortOrder` int NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `PrimaryProductId` int GENERATED ALWAYS AS ((case when (`IsPrimary` = 1) then `ProductId` else NULL end)) STORED,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `UX_ProductImages_OnePrimaryPerProduct` (`PrimaryProductId`),
  KEY `IX_ProductImages_ProductId` (`ProductId`),
  CONSTRAINT `FK_ProductImages_Products_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_ProductImages_SortOrder` CHECK ((`SortOrder` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductImages`
--

LOCK TABLES `ProductImages` WRITE;
/*!40000 ALTER TABLE `ProductImages` DISABLE KEYS */;
INSERT INTO `ProductImages` (`Id`, `ProductId`, `ImageUrl`, `IsPrimary`, `SortOrder`, `CreatedAt`) VALUES (1,3,'products/ao-dai/flane-uyenkhanh-a78b7f41388f.jpg',1,0,'2026-09-09 15:47:49.000000'),(2,4,'products/ao-dai/linn-design-tue-hien-d3ac5a259dfc.jpg',1,0,'2026-09-09 15:47:49.000000'),(3,5,'products/ao-dai/mainichi-moc-mien-01806b1b979a.png',1,0,'2026-09-09 15:47:50.000000'),(4,6,'products/ao-dai/mainichi-yen-chi-f9570e47ee6b.jpg',1,0,'2026-09-09 15:47:50.000000'),(5,7,'products/ao-dai/maison-long-niem-no-800686bb8652.jpg',1,0,'2026-09-09 15:47:50.000000'),(6,8,'products/ao-dai/dchic-nang-tho-pho-hoi-210371af8908.jpg',1,0,'2026-09-09 15:47:50.000000'),(7,9,'products/ao-dai/dchic-couture-11a66bffc46b.jpg',1,0,'2026-09-09 15:47:50.000000'),(8,10,'products/ao-dai/d-chic-xuan-vien-639f979153cf.jpg',1,0,'2026-09-09 15:47:50.000000'),(9,11,'products/ao-dai/dchic-y-nhien-4bd76df1ba20.jpg',1,0,'2026-09-09 15:47:50.000000'),(10,12,'products/ao-dai/d-chic-thien-y-211c0ae58a7c.jpg',1,0,'2026-09-09 15:47:50.000000'),(11,13,'products/vay-di-bien/tipblu-dam-voan-tim-lavender-04c915896be0.jpg',1,0,'2026-09-09 15:47:50.000000'),(12,14,'products/vay-di-bien/chou-chou-dam-ren-nude-dang-dai-bb93b72ae214.jpg',1,0,'2026-09-09 15:47:50.000000'),(13,15,'products/vay-di-bien/amelie-vanessa-dress-xanh-nhat-f3db7d3e4f8a.jpg',1,0,'2026-09-09 15:47:50.000000'),(14,16,'products/vay-di-bien/jolie-loft-vay-luoi-molly-dress-nau-d92038751836.jpg',1,0,'2026-09-09 15:47:50.000000'),(15,17,'products/vay-di-bien/flane-ren-co-yem-1939b585e2b8.jpg',1,0,'2026-09-09 15:47:51.000000'),(16,18,'products/vay-di-bien/jolie-loft-lua-540f8a0c0d21.jpg',1,0,'2026-09-09 15:47:51.000000'),(17,19,'products/vay-di-bien/jolie-loft-vay-ren-co-tay-3711af677a87.jpg',1,0,'2026-09-09 15:47:51.000000'),(18,20,'products/vay-di-bien/flane-ren-bo-mui-tre-vai-de0c667f796d.jpg',1,0,'2026-09-09 15:47:51.000000'),(19,21,'products/vay-di-bien/amelie-vay-bi-babydoll-co-yem-52e248e5a8ed.jpg',1,0,'2026-09-09 15:47:51.000000'),(20,22,'products/vay-di-bien/vay-ren-phoi-to-558d4ffd5f68.jpg',1,0,'2026-09-09 15:47:51.000000'),(21,23,'products/vay-di-bien/ameliee-garment-ccde6967b35d.jpg',1,0,'2026-09-09 15:47:51.000000'),(22,24,'products/vay-di-bien/ameliee-diva-ac220ddca95e.webp',1,0,'2026-09-09 15:47:51.000000'),(23,25,'products/vay-di-bien/maison-long-thuy-mi-ba34b0b11855.jpg',1,0,'2026-09-09 15:47:52.000000'),(24,26,'products/vay-di-bien/vay-hoa-mua-he-d401aad8191e.jpg',1,0,'2026-09-09 15:47:52.000000'),(25,27,'products/vay-di-bien/set-vay-2-day-chan-vay-trang-kem-lannie-6f9b34578bac.jpg',1,0,'2026-09-09 15:47:52.000000'),(26,28,'products/vay-du-tiec/so-vintage-nathalia-dd392dda95e4.jpg',1,0,'2026-09-09 15:47:52.000000'),(27,29,'products/vay-di-bien/tipblu-dam-voan-tim-lavender-04c915896be0.jpg',1,0,'2026-09-09 15:47:52.000000'),(28,30,'products/vay-du-tiec/jolie-loft-dam-lua-kem-hali-dress-44d474fd0419.jpg',1,0,'2026-09-09 15:47:52.000000'),(29,31,'products/vay-di-bien/chou-chou-dam-ren-nude-dang-dai-bb93b72ae214.jpg',1,0,'2026-09-09 15:47:52.000000'),(30,32,'products/vay-di-bien/amelie-vanessa-dress-xanh-nhat-f3db7d3e4f8a.jpg',1,0,'2026-09-09 15:47:52.000000'),(31,33,'products/vay-di-bien/jolie-loft-vay-luoi-molly-dress-nau-d92038751836.jpg',1,0,'2026-09-09 15:47:52.000000'),(32,34,'products/vay-du-tiec/so-vintage-lyra-9e14be9fc742.jpg',1,0,'2026-09-09 15:47:52.000000'),(33,35,'products/vay-du-tiec/wonder-house-lua-dress-kem-2b53e05ea2bd.jpg',1,0,'2026-09-09 15:47:52.000000'),(34,36,'products/vay-du-tiec/so-vintage-velia-den-497b75ce734f.jpg',1,0,'2026-09-09 15:47:52.000000'),(35,37,'products/vay-du-tiec/so-vintage-veliana-den-89e3bccbb579.jpg',1,0,'2026-09-09 15:47:53.000000'),(36,38,'products/vay-du-tiec/chouchou-dam-dai-ren-choang-345fd9ebe974.jpg',1,0,'2026-09-09 15:47:53.000000'),(37,39,'products/vay-du-tiec/so-vintage-velia-3ec75e026681.jpg',1,0,'2026-09-09 15:47:53.000000'),(38,40,'products/vay-du-tiec/so-vintage-lafine-2f073b76c8e4.jpg',1,0,'2026-09-09 15:47:53.000000'),(39,41,'products/vay-du-tiec/so-vintage-veliana-651d05688ec4.png',1,0,'2026-09-09 15:47:53.000000'),(40,42,'products/vay-du-tiec/jolie-loft-vay-lua-luala-dress-1e3a1a9cd26e.png',1,0,'2026-09-09 15:47:53.000000'),(41,43,'products/vay-du-tiec/huong-boutique-louise-lace-dress-1be1361fc923.jpg',1,0,'2026-09-09 15:47:54.000000'),(42,44,'products/phu-kien/tui-nhung-den-dchic-9d2e3d1a6c98.jpg',1,0,'2026-09-09 15:47:54.000000'),(43,45,'products/phu-kien/tui-da-den-mysp-5db7212e7337.jpg',1,0,'2026-09-09 15:47:54.000000'),(44,46,'products/phu-kien/tui-da-do-ac94ff1d6b71.jpg',1,0,'2026-09-09 15:47:54.000000'),(45,47,'products/phu-kien/tui-trung-ngoc-trai-56969992dfbf.jpg',1,0,'2026-09-09 15:47:54.000000'),(46,48,'products/phu-kien/com-bo-phu-kien-ao-dai-14d0ec771a02.jpg',1,0,'2026-09-09 15:47:54.000000'),(47,49,'products/phu-kien/combo-ngoc-trai-852e46f9db0f.jpg',1,0,'2026-09-09 15:47:55.000000'),(48,50,'products/phu-kien/tui-mu-di-bien-41a286f65c0d.jpg',1,0,'2026-09-09 15:47:55.000000'),(49,51,'products/vay-du-tiec/jolie-loft-dam-lua-kem-hali-dress-44d474fd0419.jpg',1,0,'2026-09-09 15:47:55.000000'),(50,52,'products/vay-du-tiec/wonder-house-lua-dress-kem-2b53e05ea2bd.jpg',1,0,'2026-09-09 15:47:55.000000'),(51,53,'products/vay-du-tiec/jolie-loft-vay-lua-luala-dress-1e3a1a9cd26e.png',1,0,'2026-09-09 15:47:55.000000'),(52,54,'products/vay-di-bien/jolie-loft-lua-540f8a0c0d21.jpg',1,0,'2026-09-09 15:47:55.000000');
/*!40000 ALTER TABLE `ProductImages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductInventoryItems`
--

DROP TABLE IF EXISTS `ProductInventoryItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductInventoryItems` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ProductVariantId` int NOT NULL,
  `AssetCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Condition` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Notes` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `AcquiredAt` datetime(6) DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_ProductInventoryItems_AssetCode` (`AssetCode`),
  KEY `IX_ProductInventoryItems_ProductVariantId` (`ProductVariantId`),
  KEY `IX_ProductInventoryItems_Status` (`Status`),
  CONSTRAINT `FK_ProductInventoryItems_ProductVariants_ProductVariantId` FOREIGN KEY (`ProductVariantId`) REFERENCES `ProductVariants` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_ProductInventoryItems_Condition` CHECK ((`Condition` in (_utf8mb4'NEW',_utf8mb4'GOOD',_utf8mb4'FAIR',_utf8mb4'WORN',_utf8mb4'DAMAGED'))),
  CONSTRAINT `CK_ProductInventoryItems_Status` CHECK ((`Status` in (_utf8mb4'AVAILABLE',_utf8mb4'RESERVED',_utf8mb4'RENTED',_utf8mb4'CLEANING',_utf8mb4'MAINTENANCE',_utf8mb4'DAMAGED',_utf8mb4'LOST',_utf8mb4'RETIRED')))
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductInventoryItems`
--

LOCK TABLES `ProductInventoryItems` WRITE;
/*!40000 ALTER TABLE `ProductInventoryItems` DISABLE KEYS */;
INSERT INTO `ProductInventoryItems` VALUES (1,7,'LEGACY-ao-dai-flane-uyen-khanh-ao-dai-flane-uyenkhanh-8z8gmn-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:49.000000',NULL),(2,8,'LEGACY-ao-dai-linn-design-tue-hien-ao-dai-linn-design-tue-hien-1yru53-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:49.000000',NULL),(3,9,'LEGACY-ao-dai-mainichi-moc-mien-ao-dai-mainichi-moc-mien-juw8tf-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(4,10,'LEGACY-ao-dai-mainichi-yen-chi-ao-dai-mainichi-yen-chi-1lr828n-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(5,11,'LEGACY-ao-dai-maison-long-niem-noi-ao-dai-maison-long-niem-no-pt6vex-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(6,12,'LEGACY-ao-dai-d-chic-nang-tho-pho-hoi-ao-dai-dchic-nang-tho-pho-hoi-1q4eyyu-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(7,13,'LEGACY-ao-dai-d-chic-couture-ao-dai-dchic-couture-prvi2c-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(8,14,'LEGACY-ao-dai-d-chic-xuan-vien-ao-dai-d-chic-xuan-vien-yoer7m-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(9,15,'LEGACY-ao-dai-d-chic-y-nhien-ao-dai-dchic-y-nhien-1w3oedd-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(10,16,'LEGACY-ao-dai-d-chic-thien-y-ao-dai-d-chic-thien-y-169pne2-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(11,17,'LEGACY-vay-di-bien-tipblu-am-voan-tim-lavender-vay-di-bien-tipblu-dam-voan-tim-lavender-bv6xu-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(12,18,'LEGACY-vay-di-bien-chouchou-am-ren-nude-dang-dai-vay-di-bien-chou-chou-dam-ren-nude-dang-dai-16q7a7u','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(13,19,'LEGACY-vay-di-bien-amelie-vanessa-dress-xanh-nhat-vay-di-bien-amelie-vanessa-dress-xanh-nhat-1x4eyxi','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(14,20,'LEGACY-vay-di-bien-jolie-loft-vay-luoi-molly-dress-nau-vay-di-bien-jolie-loft-vay-luoi-molly-dress-n','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:50.000000',NULL),(15,21,'LEGACY-vay-di-bien-flane-ren-co-yem-vay-di-bien-flane-ren-co-yem-1dle7t4-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:51.000000',NULL),(16,22,'LEGACY-vay-di-bien-jolie-loft-lua-vay-di-bien-jolie-loft-lua-q611c5-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:51.000000',NULL),(17,23,'LEGACY-vay-di-bien-jolie-loft-vay-ren-co-tay-vay-di-bien-jolie-loft-vay-ren-co-tay-zi6pwf-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:51.000000',NULL),(18,24,'LEGACY-vay-di-bien-flane-ren-bo-mui-tre-vai-vay-di-bien-flane-ren-bo-mui-tre-vai-1d1b3z0-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:51.000000',NULL),(19,25,'LEGACY-vay-di-bien-amelie-vay-bi-babydoll-co-yem-vay-di-bien-amelie-vay-bi-babydoll-co-yem-pep3hg-00','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:51.000000',NULL),(20,26,'LEGACY-vay-di-bien-vay-ren-phoi-to-vay-di-bien-vay-ren-phoi-to-1f5jr2e-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:51.000000',NULL),(21,27,'LEGACY-vay-di-bien-ameliee-garment-vay-di-bien-ameliee-garment-11m6igq-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:51.000000',NULL),(22,28,'LEGACY-vay-di-bien-ameliee-diva-vay-di-bien-ameliee-diva-ifg3xf-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(23,29,'LEGACY-vay-di-bien-maison-long-thuy-mi-vay-di-bien-maison-long-thuy-mi-hyfev7-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(24,30,'LEGACY-vay-di-bien-vay-hoa-mua-he-vay-di-bien-vay-hoa-mua-he-atur42-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(25,31,'LEGACY-vay-di-bien-set-vay-2-day-chan-vay-trang-kem-lannie-vay-di-bien-set-vay-2-day-chan-vay-trang-','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(26,32,'LEGACY-vay-du-tiec-so-vintage-nathalia-vay-du-tiec-so-vintage-nathalia-llfhl5-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(27,33,'LEGACY-vay-du-tiec-tipblu-am-voan-tim-lavender-vay-du-tiec-tipblu-dam-voan-tim-lavender-1guk5xm-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(28,34,'LEGACY-vay-du-tiec-jolie-loft-am-lua-kem-hali-dress-vay-du-tiec-jolie-loft-dam-lua-kem-hali-dress-1i','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(29,35,'LEGACY-vay-du-tiec-chouchou-am-ren-nude-dang-dai-vay-du-tiec-chouchou-dam-ren-nude-dang-dai-ii7pet-0','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(30,36,'LEGACY-vay-du-tiec-amelie-vanessa-dress-xanh-nhat-vay-du-tiec-amelie-vanessa-dress-xanh-nhat-z6h2gu-','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(31,37,'LEGACY-vay-du-tiec-jolie-loft-vay-luoi-molly-dress-nau-vay-du-tiec-jolie-loft-vay-luoi-molly-dress-n','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(32,38,'LEGACY-vay-du-tiec-so-vintage-lyra-vay-du-tiec-so-vintage-lyra-pyr7px-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(33,39,'LEGACY-vay-du-tiec-wonder-house-lua-dress-kem-vay-du-tiec-wonder-house-lua-dress-kem-rda8py-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:52.000000',NULL),(34,40,'LEGACY-vay-du-tiec-so-vintage-velia-en-vay-du-tiec-so-vintage-velia-den-1ji4oa2-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:53.000000',NULL),(35,41,'LEGACY-vay-du-tiec-so-vintage-veliana-en-vay-du-tiec-so-vintage-veliana-den-uzwso5-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:53.000000',NULL),(36,42,'LEGACY-vay-du-tiec-chouchou-am-dai-ren-choang-vay-du-tiec-chouchou-dam-dai-ren-choang-tg9ixw-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:53.000000',NULL),(37,43,'LEGACY-vay-du-tiec-so-vintage-velia-vay-du-tiec-so-vintage-velia-y1vsf6-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:53.000000',NULL),(38,44,'LEGACY-vay-du-tiec-so-vintage-lafine-vay-du-tiec-so-vintage-lafine-8x79h4-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:53.000000',NULL),(39,45,'LEGACY-vay-du-tiec-so-vintage-veliana-vay-du-tiec-so-vintage-veliana-1tczsa7-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:53.000000',NULL),(40,46,'LEGACY-vay-du-tiec-jolie-loft-vay-lua-luala-dress-vay-du-tiec-jolie-loft-vay-lua-luala-dress-dyy77c-','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:53.000000',NULL),(41,47,'LEGACY-vay-du-tiec-huong-boutique-louise-lace-dress-vay-du-tiec-huong-boutique-louise-lace-dress-y2b','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:54.000000',NULL),(42,48,'LEGACY-phu-kien-tui-nhung-en-d-chic-phu-kien-tui-nhung-den-dchic-ga4mx8-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:54.000000',NULL),(43,49,'LEGACY-phu-kien-tui-da-en-mys-p-phu-kien-tui-da-den-mysp-1dy6iz-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:54.000000',NULL),(44,50,'LEGACY-phu-kien-tui-da-o-phu-kien-tui-da-do-1hprfk3-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:54.000000',NULL),(45,51,'LEGACY-phu-kien-tui-trung-ngoc-trai-phu-kien-tui-trung-ngoc-trai-1vjmm0d-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:54.000000',NULL),(46,52,'LEGACY-phu-kien-combo-phu-kien-ao-dai-vong-bom-tui-phu-kien-com-bo-phu-kien-ao-dai-1gzwtn0-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:55.000000',NULL),(47,53,'LEGACY-phu-kien-combo-ngoc-trai-tui-vong-co-tui-bom-vong-tay-phu-kien-combo-ngoc-trai-16poe5w-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:55.000000',NULL),(48,54,'LEGACY-phu-kien-tui-mu-i-bien-phu-kien-tui-mu-di-bien-1731mbr-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:55.000000',NULL),(49,55,'LEGACY-vay-lua-jolie-loft-am-lua-kem-hali-dress-vay-lua-jolie-loft-dam-lua-kem-hali-dress-1ot7kqt-00','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:55.000000',NULL),(50,56,'LEGACY-vay-lua-wonder-house-lua-dress-kem-vay-lua-wonder-house-lua-dress-kem-fiadoc-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:55.000000',NULL),(51,57,'LEGACY-vay-lua-jolie-loft-vay-lua-luala-dress-vay-lua-jolie-loft-vaylua-dress-1o6ik3-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:55.000000',NULL),(52,58,'LEGACY-vay-lua-jolie-loft-lua-vay-lua-jolie-loft-lua-1ewpzgj-001','GOOD','AVAILABLE','Seeded from legacy frontend catalog',NULL,'2026-09-09 15:47:55.000000',NULL);
/*!40000 ALTER TABLE `ProductInventoryItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductLikes`
--

DROP TABLE IF EXISTS `ProductLikes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductLikes` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `ProductId` int NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_ProductLikes_UserId_ProductId` (`UserId`,`ProductId`),
  KEY `IX_ProductLikes_ProductId` (`ProductId`),
  KEY `IX_ProductLikes_UserId` (`UserId`),
  CONSTRAINT `FK_ProductLikes_Products_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_ProductLikes_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductLikes`
--

LOCK TABLES `ProductLikes` WRITE;
/*!40000 ALTER TABLE `ProductLikes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProductLikes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductMonthlyStats`
--

DROP TABLE IF EXISTS `ProductMonthlyStats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductMonthlyStats` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ProductId` int NOT NULL,
  `Year` int NOT NULL,
  `Month` int NOT NULL,
  `TotalOrders` int NOT NULL,
  `TotalQuantityRented` int NOT NULL,
  `RentRevenue` decimal(18,2) NOT NULL,
  `DepositCollected` decimal(18,2) NOT NULL,
  `DepositRefunded` decimal(18,2) NOT NULL,
  `ShippingFee` decimal(18,2) NOT NULL,
  `DiscountAmount` decimal(18,2) NOT NULL,
  `CleaningCost` decimal(18,2) NOT NULL,
  `MaintenanceCost` decimal(18,2) NOT NULL,
  `GrossProfit` decimal(18,2) GENERATED ALWAYS AS (((((`RentRevenue` - `ShippingFee`) - `DiscountAmount`) - `CleaningCost`) - `MaintenanceCost`)) STORED,
  `UpdatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_ProductMonthlyStats_ProductId_Year_Month` (`ProductId`,`Year`,`Month`),
  KEY `IX_ProductMonthlyStats_ProductId` (`ProductId`),
  KEY `IX_ProductMonthlyStats_Year_Month` (`Year`,`Month`),
  CONSTRAINT `FK_ProductMonthlyStats_Products_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_ProductMonthlyStats_CleaningCost` CHECK ((`CleaningCost` >= 0)),
  CONSTRAINT `CK_ProductMonthlyStats_DepositCollected` CHECK ((`DepositCollected` >= 0)),
  CONSTRAINT `CK_ProductMonthlyStats_DepositRefunded` CHECK ((`DepositRefunded` >= 0)),
  CONSTRAINT `CK_ProductMonthlyStats_DiscountAmount` CHECK ((`DiscountAmount` >= 0)),
  CONSTRAINT `CK_ProductMonthlyStats_MaintenanceCost` CHECK ((`MaintenanceCost` >= 0)),
  CONSTRAINT `CK_ProductMonthlyStats_Month` CHECK ((`Month` between 1 and 12)),
  CONSTRAINT `CK_ProductMonthlyStats_RentRevenue` CHECK ((`RentRevenue` >= 0)),
  CONSTRAINT `CK_ProductMonthlyStats_ShippingFee` CHECK ((`ShippingFee` >= 0)),
  CONSTRAINT `CK_ProductMonthlyStats_TotalOrders` CHECK ((`TotalOrders` >= 0)),
  CONSTRAINT `CK_ProductMonthlyStats_TotalQuantityRented` CHECK ((`TotalQuantityRented` >= 0)),
  CONSTRAINT `CK_ProductMonthlyStats_Year` CHECK ((`Year` >= 2000))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductMonthlyStats`
--

LOCK TABLES `ProductMonthlyStats` WRITE;
/*!40000 ALTER TABLE `ProductMonthlyStats` DISABLE KEYS */;
/*!40000 ALTER TABLE `ProductMonthlyStats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ProductVariants`
--

DROP TABLE IF EXISTS `ProductVariants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ProductVariants` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ProductId` int NOT NULL,
  `Size` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Color` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `VariantCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_ProductVariants_ProductId_Size_Color` (`ProductId`,`Size`,`Color`),
  UNIQUE KEY `IX_ProductVariants_VariantCode` (`VariantCode`),
  KEY `IX_ProductVariants_ProductId` (`ProductId`),
  CONSTRAINT `FK_ProductVariants_Products_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`Id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ProductVariants`
--

LOCK TABLES `ProductVariants` WRITE;
/*!40000 ALTER TABLE `ProductVariants` DISABLE KEYS */;
INSERT INTO `ProductVariants` VALUES (1,1,'S','White','PRD1-S-WHITE',1,'2026-09-09 07:57:54.051452',NULL),(2,1,'M','White','PRD1-M-WHITE',1,'2026-09-09 07:57:54.051460',NULL),(3,1,'L','White','PRD1-L-WHITE',1,'2026-09-09 07:57:54.051460',NULL),(4,2,'S','Xanh pastel','PRD2-S-XANH-PASTEL',1,'2026-09-09 08:03:19.443907',NULL),(5,2,'M','Xanh pastel','PRD2-M-XANH-PASTEL',1,'2026-09-09 08:03:19.443915',NULL),(6,2,'L','Xanh pastel','PRD2-L-XANH-PASTEL',1,'2026-09-09 08:03:19.443915',NULL),(7,3,'FREESIZE','ASSORTED','LEGACY-ao-dai-flane-uyen-khanh-ao-dai-flane-uyenkhanh-8z8gmn-FREESIZE-ASSORTED',1,'2026-09-09 15:47:49.000000',NULL),(8,4,'FREESIZE','ASSORTED','LEGACY-ao-dai-linn-design-tue-hien-ao-dai-linn-design-tue-hien-1yru53-FREESIZE-ASSORTED',1,'2026-09-09 15:47:49.000000',NULL),(9,5,'FREESIZE','ASSORTED','LEGACY-ao-dai-mainichi-moc-mien-ao-dai-mainichi-moc-mien-juw8tf-FREESIZE-ASSORTED',1,'2026-09-09 15:47:50.000000',NULL),(10,6,'FREESIZE','ASSORTED','LEGACY-ao-dai-mainichi-yen-chi-ao-dai-mainichi-yen-chi-1lr828n-FREESIZE-ASSORTED',1,'2026-09-09 15:47:50.000000',NULL),(11,7,'FREESIZE','ASSORTED','LEGACY-ao-dai-maison-long-niem-noi-ao-dai-maison-long-niem-no-pt6vex-FREESIZE-ASSORTED',1,'2026-09-09 15:47:50.000000',NULL),(12,8,'FREESIZE','ASSORTED','LEGACY-ao-dai-d-chic-nang-tho-pho-hoi-ao-dai-dchic-nang-tho-pho-hoi-1q4eyyu-FREESIZE-ASSORTED',1,'2026-09-09 15:47:50.000000',NULL),(13,9,'FREESIZE','ASSORTED','LEGACY-ao-dai-d-chic-couture-ao-dai-dchic-couture-prvi2c-FREESIZE-ASSORTED',1,'2026-09-09 15:47:50.000000',NULL),(14,10,'FREESIZE','ASSORTED','LEGACY-ao-dai-d-chic-xuan-vien-ao-dai-d-chic-xuan-vien-yoer7m-FREESIZE-ASSORTED',1,'2026-09-09 15:47:50.000000',NULL),(15,11,'FREESIZE','ASSORTED','LEGACY-ao-dai-d-chic-y-nhien-ao-dai-dchic-y-nhien-1w3oedd-FREESIZE-ASSORTED',1,'2026-09-09 15:47:50.000000',NULL),(16,12,'FREESIZE','ASSORTED','LEGACY-ao-dai-d-chic-thien-y-ao-dai-d-chic-thien-y-169pne2-FREESIZE-ASSORTED',1,'2026-09-09 15:47:50.000000',NULL),(17,13,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-tipblu-am-voan-tim-lavender-vay-di-bien-tipblu-dam-voan-tim-lavender-bv6xu-FREESI',1,'2026-09-09 15:47:50.000000',NULL),(18,14,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-chouchou-am-ren-nude-dang-dai-vay-di-bien-chou-chou-dam-ren-nude-dang-dai-16q7a7u',1,'2026-09-09 15:47:50.000000',NULL),(19,15,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-amelie-vanessa-dress-xanh-nhat-vay-di-bien-amelie-vanessa-dress-xanh-nhat-1x4eyxi',1,'2026-09-09 15:47:50.000000',NULL),(20,16,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-jolie-loft-vay-luoi-molly-dress-nau-vay-di-bien-jolie-loft-vay-luoi-molly-dress-n',1,'2026-09-09 15:47:50.000000',NULL),(21,17,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-flane-ren-co-yem-vay-di-bien-flane-ren-co-yem-1dle7t4-FREESIZE-ASSORTED',1,'2026-09-09 15:47:51.000000',NULL),(22,18,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-jolie-loft-lua-vay-di-bien-jolie-loft-lua-q611c5-FREESIZE-ASSORTED',1,'2026-09-09 15:47:51.000000',NULL),(23,19,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-jolie-loft-vay-ren-co-tay-vay-di-bien-jolie-loft-vay-ren-co-tay-zi6pwf-FREESIZE-A',1,'2026-09-09 15:47:51.000000',NULL),(24,20,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-flane-ren-bo-mui-tre-vai-vay-di-bien-flane-ren-bo-mui-tre-vai-1d1b3z0-FREESIZE-AS',1,'2026-09-09 15:47:51.000000',NULL),(25,21,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-amelie-vay-bi-babydoll-co-yem-vay-di-bien-amelie-vay-bi-babydoll-co-yem-pep3hg-FR',1,'2026-09-09 15:47:51.000000',NULL),(26,22,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-vay-ren-phoi-to-vay-di-bien-vay-ren-phoi-to-1f5jr2e-FREESIZE-ASSORTED',1,'2026-09-09 15:47:51.000000',NULL),(27,23,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-ameliee-garment-vay-di-bien-ameliee-garment-11m6igq-FREESIZE-ASSORTED',1,'2026-09-09 15:47:51.000000',NULL),(28,24,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-ameliee-diva-vay-di-bien-ameliee-diva-ifg3xf-FREESIZE-ASSORTED',1,'2026-09-09 15:47:51.000000',NULL),(29,25,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-maison-long-thuy-mi-vay-di-bien-maison-long-thuy-mi-hyfev7-FREESIZE-ASSORTED',1,'2026-09-09 15:47:52.000000',NULL),(30,26,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-vay-hoa-mua-he-vay-di-bien-vay-hoa-mua-he-atur42-FREESIZE-ASSORTED',1,'2026-09-09 15:47:52.000000',NULL),(31,27,'FREESIZE','ASSORTED','LEGACY-vay-di-bien-set-vay-2-day-chan-vay-trang-kem-lannie-vay-di-bien-set-vay-2-day-chan-vay-trang-',1,'2026-09-09 15:47:52.000000',NULL),(32,28,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-so-vintage-nathalia-vay-du-tiec-so-vintage-nathalia-llfhl5-FREESIZE-ASSORTED',1,'2026-09-09 15:47:52.000000',NULL),(33,29,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-tipblu-am-voan-tim-lavender-vay-du-tiec-tipblu-dam-voan-tim-lavender-1guk5xm-FREE',1,'2026-09-09 15:47:52.000000',NULL),(34,30,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-jolie-loft-am-lua-kem-hali-dress-vay-du-tiec-jolie-loft-dam-lua-kem-hali-dress-1i',1,'2026-09-09 15:47:52.000000',NULL),(35,31,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-chouchou-am-ren-nude-dang-dai-vay-du-tiec-chouchou-dam-ren-nude-dang-dai-ii7pet-F',1,'2026-09-09 15:47:52.000000',NULL),(36,32,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-amelie-vanessa-dress-xanh-nhat-vay-du-tiec-amelie-vanessa-dress-xanh-nhat-z6h2gu-',1,'2026-09-09 15:47:52.000000',NULL),(37,33,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-jolie-loft-vay-luoi-molly-dress-nau-vay-du-tiec-jolie-loft-vay-luoi-molly-dress-n',1,'2026-09-09 15:47:52.000000',NULL),(38,34,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-so-vintage-lyra-vay-du-tiec-so-vintage-lyra-pyr7px-FREESIZE-ASSORTED',1,'2026-09-09 15:47:52.000000',NULL),(39,35,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-wonder-house-lua-dress-kem-vay-du-tiec-wonder-house-lua-dress-kem-rda8py-FREESIZE',1,'2026-09-09 15:47:52.000000',NULL),(40,36,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-so-vintage-velia-en-vay-du-tiec-so-vintage-velia-den-1ji4oa2-FREESIZE-ASSORTED',1,'2026-09-09 15:47:53.000000',NULL),(41,37,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-so-vintage-veliana-en-vay-du-tiec-so-vintage-veliana-den-uzwso5-FREESIZE-ASSORTED',1,'2026-09-09 15:47:53.000000',NULL),(42,38,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-chouchou-am-dai-ren-choang-vay-du-tiec-chouchou-dam-dai-ren-choang-tg9ixw-FREESIZ',1,'2026-09-09 15:47:53.000000',NULL),(43,39,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-so-vintage-velia-vay-du-tiec-so-vintage-velia-y1vsf6-FREESIZE-ASSORTED',1,'2026-09-09 15:47:53.000000',NULL),(44,40,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-so-vintage-lafine-vay-du-tiec-so-vintage-lafine-8x79h4-FREESIZE-ASSORTED',1,'2026-09-09 15:47:53.000000',NULL),(45,41,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-so-vintage-veliana-vay-du-tiec-so-vintage-veliana-1tczsa7-FREESIZE-ASSORTED',1,'2026-09-09 15:47:53.000000',NULL),(46,42,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-jolie-loft-vay-lua-luala-dress-vay-du-tiec-jolie-loft-vay-lua-luala-dress-dyy77c-',1,'2026-09-09 15:47:53.000000',NULL),(47,43,'FREESIZE','ASSORTED','LEGACY-vay-du-tiec-huong-boutique-louise-lace-dress-vay-du-tiec-huong-boutique-louise-lace-dress-y2b',1,'2026-09-09 15:47:54.000000',NULL),(48,44,'FREESIZE','ASSORTED','LEGACY-phu-kien-tui-nhung-en-d-chic-phu-kien-tui-nhung-den-dchic-ga4mx8-FREESIZE-ASSORTED',1,'2026-09-09 15:47:54.000000',NULL),(49,45,'FREESIZE','ASSORTED','LEGACY-phu-kien-tui-da-en-mys-p-phu-kien-tui-da-den-mysp-1dy6iz-FREESIZE-ASSORTED',1,'2026-09-09 15:47:54.000000',NULL),(50,46,'FREESIZE','ASSORTED','LEGACY-phu-kien-tui-da-o-phu-kien-tui-da-do-1hprfk3-FREESIZE-ASSORTED',1,'2026-09-09 15:47:54.000000',NULL),(51,47,'FREESIZE','ASSORTED','LEGACY-phu-kien-tui-trung-ngoc-trai-phu-kien-tui-trung-ngoc-trai-1vjmm0d-FREESIZE-ASSORTED',1,'2026-09-09 15:47:54.000000',NULL),(52,48,'FREESIZE','ASSORTED','LEGACY-phu-kien-combo-phu-kien-ao-dai-vong-bom-tui-phu-kien-com-bo-phu-kien-ao-dai-1gzwtn0-FREESIZE-',1,'2026-09-09 15:47:54.000000',NULL),(53,49,'FREESIZE','ASSORTED','LEGACY-phu-kien-combo-ngoc-trai-tui-vong-co-tui-bom-vong-tay-phu-kien-combo-ngoc-trai-16poe5w-FREESI',1,'2026-09-09 15:47:55.000000',NULL),(54,50,'FREESIZE','ASSORTED','LEGACY-phu-kien-tui-mu-i-bien-phu-kien-tui-mu-di-bien-1731mbr-FREESIZE-ASSORTED',1,'2026-09-09 15:47:55.000000',NULL),(55,51,'FREESIZE','ASSORTED','LEGACY-vay-lua-jolie-loft-am-lua-kem-hali-dress-vay-lua-jolie-loft-dam-lua-kem-hali-dress-1ot7kqt-FR',1,'2026-09-09 15:47:55.000000',NULL),(56,52,'FREESIZE','ASSORTED','LEGACY-vay-lua-wonder-house-lua-dress-kem-vay-lua-wonder-house-lua-dress-kem-fiadoc-FREESIZE-ASSORTE',1,'2026-09-09 15:47:55.000000',NULL),(57,53,'FREESIZE','ASSORTED','LEGACY-vay-lua-jolie-loft-vay-lua-luala-dress-vay-lua-jolie-loft-vaylua-dress-1o6ik3-FREESIZE-ASSORT',1,'2026-09-09 15:47:55.000000',NULL),(58,54,'FREESIZE','ASSORTED','LEGACY-vay-lua-jolie-loft-lua-vay-lua-jolie-loft-lua-1ewpzgj-FREESIZE-ASSORTED',1,'2026-09-09 15:47:55.000000',NULL);
/*!40000 ALTER TABLE `ProductVariants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Products`
--

DROP TABLE IF EXISTS `Products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Products` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ShopId` int DEFAULT NULL,
  `CategoryId` int DEFAULT NULL,
  `BrandId` int DEFAULT NULL,
  `Name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Slug` varchar(220) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `Price1Day` decimal(18,2) NOT NULL,
  `Price3Day` decimal(18,2) NOT NULL,
  `ExtraDayPrice` decimal(18,2) NOT NULL,
  `PriceTag` decimal(18,2) DEFAULT NULL,
  `PriceDeposit` decimal(18,2) NOT NULL,
  `PurchaseCost` decimal(18,2) DEFAULT NULL,
  `CleaningCost` decimal(18,2) NOT NULL,
  `MaintenanceCost` decimal(18,2) NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  `UserId` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Products_Slug` (`Slug`),
  KEY `IX_Products_BrandId` (`BrandId`),
  KEY `IX_Products_CategoryId` (`CategoryId`),
  KEY `IX_Products_IsActive` (`IsActive`),
  KEY `IX_Products_ShopId` (`ShopId`),
  KEY `IX_Products_UserId` (`UserId`),
  CONSTRAINT `FK_Products_Brands_BrandId` FOREIGN KEY (`BrandId`) REFERENCES `Brands` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Products_Categories_CategoryId` FOREIGN KEY (`CategoryId`) REFERENCES `Categories` (`Id`),
  CONSTRAINT `FK_Products_Shops_ShopId` FOREIGN KEY (`ShopId`) REFERENCES `Shops` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Products_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`),
  CONSTRAINT `CK_Products_CleaningCost` CHECK ((`CleaningCost` >= 0)),
  CONSTRAINT `CK_Products_ExtraDayPrice` CHECK ((`ExtraDayPrice` >= 0)),
  CONSTRAINT `CK_Products_MaintenanceCost` CHECK ((`MaintenanceCost` >= 0)),
  CONSTRAINT `CK_Products_Price1Day` CHECK ((`Price1Day` >= 0)),
  CONSTRAINT `CK_Products_Price3Day` CHECK ((`Price3Day` >= 0)),
  CONSTRAINT `CK_Products_PriceDeposit` CHECK ((`PriceDeposit` >= 0)),
  CONSTRAINT `CK_Products_PriceTag` CHECK (((`PriceTag` is null) or (`PriceTag` >= 0))),
  CONSTRAINT `CK_Products_PurchaseCost` CHECK (((`PurchaseCost` is null) or (`PurchaseCost` >= 0)))
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Products`
--

LOCK TABLES `Products` WRITE;
/*!40000 ALTER TABLE `Products` DISABLE KEYS */;
INSERT INTO `Products` VALUES (1,2,NULL,3,'Đầm FLANE Uyên Khanh','đầm-flane-uyên-khanh','Đầm dự tiệc nữ màu trắng',260000.00,300000.00,50000.00,2500000.00,1000000.00,1800000.00,50000.00,20000.00,1,'2026-09-09 07:57:54.050744',NULL,NULL),(2,2,NULL,17,'LINN DESIGN - TUỆ HIỀN','linn-design---tuệ-hiền','Áo dài nữ màu xanh pastel với họa tiết thêu nhẹ, thiết kế thanh lịch, phù hợp chụp ảnh, lễ Tết và các dịp truyền thống.',295000.00,340000.00,50000.00,1590000.00,1200000.00,1250000.00,50000.00,30000.00,1,'2026-09-09 08:03:19.443255',NULL,NULL),(3,2,NULL,3,'FLANE – UYỂN KHANH','ao-dai-flane-uyen-khanh-ao-dai-flane-uyenkhanh-8z8gmn','Áo dài',260000.00,300000.00,350000.00,1900000.00,1200000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:49.000000',NULL,NULL),(4,2,NULL,18,'LINN DESIGN – TUỆ HIỀN','ao-dai-linn-design-tue-hien-ao-dai-linn-design-tue-hien-1yru53','Áo dài',295000.00,340000.00,350000.00,1590000.00,1200000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:49.000000',NULL,NULL),(5,2,NULL,19,'MAINICHI – MỘC MIÊN','ao-dai-mainichi-moc-mien-ao-dai-mainichi-moc-mien-juw8tf','Áo dài',220000.00,260000.00,350000.00,1200000.00,800000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(6,2,NULL,19,'MAINICHI – YÊN CHI','ao-dai-mainichi-yen-chi-ao-dai-mainichi-yen-chi-1lr828n','Áo dài',250000.00,290000.00,350000.00,1550000.00,900000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(7,2,NULL,8,'MAISON LONG – NIỀM NỖI','ao-dai-maison-long-niem-noi-ao-dai-maison-long-niem-no-pt6vex','Áo dài',180000.00,220000.00,350000.00,1150000.00,700000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(8,2,NULL,2,'D.CHIC NÀNG THƠ PHỐ HỘI','ao-dai-d-chic-nang-tho-pho-hoi-ao-dai-dchic-nang-tho-pho-hoi-1q4eyyu','Áo dài',280000.00,320000.00,350000.00,1950000.00,1200000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(9,2,NULL,2,'D.CHIC COUTURE','ao-dai-d-chic-couture-ao-dai-dchic-couture-prvi2c','Áo dài',450000.00,500000.00,350000.00,3500000.00,2000000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(10,2,NULL,2,'D.CHIC XUÂN VIÊN','ao-dai-d-chic-xuan-vien-ao-dai-d-chic-xuan-vien-yoer7m','Áo dài',440000.00,480000.00,350000.00,2850000.00,2000000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(11,2,NULL,2,'D.CHIC Ý NHIÊN','ao-dai-d-chic-y-nhien-ao-dai-dchic-y-nhien-1w3oedd','Áo dài',450000.00,490000.00,350000.00,2950000.00,2000000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(12,2,NULL,2,'D.CHIC THIÊN Ý','ao-dai-d-chic-thien-y-ao-dai-d-chic-thien-y-169pne2','Áo dài',410000.00,450000.00,350000.00,2600000.00,1900000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(13,2,NULL,18,'TIPBLU – ĐẦM VOAN TÍM LAVENDER','vay-di-bien-tipblu-am-voan-tim-lavender-vay-di-bien-tipblu-dam-voan-tim-lavender-bv6xu','Váy đi biển',160000.00,190000.00,330000.00,930000.00,650000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(14,2,NULL,15,'CHOUCHOU – ĐẦM REN NUDE DÁNG DÀI','vay-di-bien-chouchou-am-ren-nude-dang-dai-vay-di-bien-chou-chou-dam-ren-nude-dang-dai-16q7a7u','Váy đi biển',225000.00,255000.00,330000.00,1110000.00,800000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(15,2,NULL,14,'AMELIE – VANESSA DRESS XANH NHẠT','vay-di-bien-amelie-vanessa-dress-xanh-nhat-vay-di-bien-amelie-vanessa-dress-xanh-nhat-1x4eyxi','Váy đi biển',250000.00,290000.00,340000.00,1530000.00,900000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(16,2,NULL,7,'JOLIE LOFT – VÁY LƯỚI MOLLY DRESS NÂU','vay-di-bien-jolie-loft-vay-luoi-molly-dress-nau-vay-di-bien-jolie-loft-vay-luoi-molly-dress-nau-1ve9foa','Váy đi biển',230000.00,270000.00,330000.00,2150000.00,800000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(17,2,NULL,3,'FLANE – REN CỔ YẾM','vay-di-bien-flane-ren-co-yem-vay-di-bien-flane-ren-co-yem-1dle7t4','Váy đi biển',200000.00,240000.00,330000.00,1080000.00,800000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:50.000000',NULL,NULL),(18,2,NULL,7,'JOLIE LOFT – LỤA','vay-di-bien-jolie-loft-lua-vay-di-bien-jolie-loft-lua-q611c5','Váy đi biển',165000.00,195000.00,330000.00,1320000.00,700000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:51.000000',NULL,NULL),(19,2,NULL,7,'JOLIE LOFT – VÁY REN CÓ TAY','vay-di-bien-jolie-loft-vay-ren-co-tay-vay-di-bien-jolie-loft-vay-ren-co-tay-zi6pwf','Váy đi biển',190000.00,220000.00,330000.00,1812000.00,700000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:51.000000',NULL,NULL),(20,2,NULL,3,'FLANE – REN BỒ MÙI TRẺ VAI','vay-di-bien-flane-ren-bo-mui-tre-vai-vay-di-bien-flane-ren-bo-mui-tre-vai-1d1b3z0','Váy đi biển',165000.00,195000.00,340000.00,1006500.00,700000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:51.000000',NULL,NULL),(21,2,NULL,14,'AMELIE – VÁY BÍ BABYDOLL CỔ YẾM','vay-di-bien-amelie-vay-bi-babydoll-co-yem-vay-di-bien-amelie-vay-bi-babydoll-co-yem-pep3hg','Váy đi biển',140000.00,170000.00,340000.00,870000.00,600000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:51.000000',NULL,NULL),(22,2,NULL,18,'VÁY REN PHỐI TƠ','vay-di-bien-vay-ren-phoi-to-vay-di-bien-vay-ren-phoi-to-1f5jr2e','Váy đi biển',100000.00,130000.00,330000.00,680000.00,400000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:51.000000',NULL,NULL),(23,2,NULL,14,'AMELIEE – GARMENT','vay-di-bien-ameliee-garment-vay-di-bien-ameliee-garment-11m6igq','Váy đi biển',140000.00,175000.00,340000.00,888000.00,700000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:51.000000',NULL,NULL),(24,2,NULL,14,'AMELIEE – DIVA','vay-di-bien-ameliee-diva-vay-di-bien-ameliee-diva-ifg3xf','Váy đi biển',150000.00,190000.00,340000.00,960000.00,700000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:51.000000',NULL,NULL),(25,2,NULL,8,'MAISON LONG – THỦY MỊ','vay-di-bien-maison-long-thuy-mi-vay-di-bien-maison-long-thuy-mi-hyfev7','Váy đi biển',190000.00,230000.00,350000.00,1250000.00,750000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(26,2,NULL,18,'VÁY HOA MÙA HÈ','vay-di-bien-vay-hoa-mua-he-vay-di-bien-vay-hoa-mua-he-atur42','Váy đi biển',90000.00,120000.00,330000.00,594000.00,300000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(27,2,NULL,18,'SET VÁY 2 DÂY + CHÂN VÁY TRẮNG KEM LANNIE','vay-di-bien-set-vay-2-day-chan-vay-trang-kem-lannie-vay-di-bien-set-vay-2-day-chan-vay-trang-kem-lannie-1m0b65x','Váy đi biển',100000.00,120000.00,330000.00,650000.00,400000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(28,2,NULL,1,'SÒ VINTAGE – NATHALIA','vay-du-tiec-so-vintage-nathalia-vay-du-tiec-so-vintage-nathalia-llfhl5','Váy dự tiệc',490000.00,560000.00,350000.00,3620000.00,2000000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(29,2,NULL,18,'TIPBLU – ĐẦM VOAN TÍM LAVENDER','vay-du-tiec-tipblu-am-voan-tim-lavender-vay-du-tiec-tipblu-dam-voan-tim-lavender-1guk5xm','Váy dự tiệc',160000.00,190000.00,330000.00,930000.00,650000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(30,2,NULL,7,'JOLIE LOFT – ĐẦM LỤA KEM HALI DRESS','vay-du-tiec-jolie-loft-am-lua-kem-hali-dress-vay-du-tiec-jolie-loft-dam-lua-kem-hali-dress-1izut8z','Váy dự tiệc',175000.00,200000.00,330000.00,1600000.00,600000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(31,2,NULL,15,'CHOUCHOU – ĐẦM REN NUDE DÁNG DÀI','vay-du-tiec-chouchou-am-ren-nude-dang-dai-vay-du-tiec-chouchou-dam-ren-nude-dang-dai-ii7pet','Váy dự tiệc',225000.00,255000.00,330000.00,1110000.00,800000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(32,2,NULL,14,'AMELIE – VANESSA DRESS XANH NHẠT','vay-du-tiec-amelie-vanessa-dress-xanh-nhat-vay-du-tiec-amelie-vanessa-dress-xanh-nhat-z6h2gu','Váy dự tiệc',250000.00,290000.00,340000.00,1530000.00,900000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(33,2,NULL,7,'JOLIE LOFT – VÁY LƯỚI MOLLY DRESS NÂU','vay-du-tiec-jolie-loft-vay-luoi-molly-dress-nau-vay-du-tiec-jolie-loft-vay-luoi-molly-dress-nau-ig33oi','Váy dự tiệc',230000.00,270000.00,330000.00,2150000.00,800000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(34,2,NULL,1,'SÒ VINTAGE – LYRA','vay-du-tiec-so-vintage-lyra-vay-du-tiec-so-vintage-lyra-pyr7px','Váy dự tiệc',388000.00,420000.00,350000.00,2388000.00,1500000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(35,2,NULL,18,'WONDER HOUSE – LUA DRESS KEM','vay-du-tiec-wonder-house-lua-dress-kem-vay-du-tiec-wonder-house-lua-dress-kem-rda8py','Váy dự tiệc',165000.00,190000.00,330000.00,795000.00,500000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(36,2,NULL,1,'SÒ VINTAGE – VELIA (ĐEN)','vay-du-tiec-so-vintage-velia-en-vay-du-tiec-so-vintage-velia-den-1ji4oa2','Váy dự tiệc',390000.00,440000.00,350000.00,2590000.00,1500000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:52.000000',NULL,NULL),(37,2,NULL,1,'SÒ VINTAGE – VELIANA (ĐEN)','vay-du-tiec-so-vintage-veliana-en-vay-du-tiec-so-vintage-veliana-den-uzwso5','Váy dự tiệc',290000.00,340000.00,350000.00,1969000.00,1300000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:53.000000',NULL,NULL),(38,2,NULL,15,'CHOUCHOU – ĐẦM DÀI REN CHOÀNG','vay-du-tiec-chouchou-am-dai-ren-choang-vay-du-tiec-chouchou-dam-dai-ren-choang-tg9ixw','Váy dự tiệc',200000.00,230000.00,330000.00,990000.00,700000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:53.000000',NULL,NULL),(39,2,NULL,1,'SÒ VINTAGE – VELIA','vay-du-tiec-so-vintage-velia-vay-du-tiec-so-vintage-velia-y1vsf6','Váy dự tiệc',390000.00,440000.00,350000.00,2590000.00,1500000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:53.000000',NULL,NULL),(40,2,NULL,1,'SÒ VINTAGE – LAFINE','vay-du-tiec-so-vintage-lafine-vay-du-tiec-so-vintage-lafine-8x79h4','Váy dự tiệc',400000.00,450000.00,350000.00,2629000.00,1500000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:53.000000',NULL,NULL),(41,2,NULL,1,'SÒ VINTAGE – VELIANA','vay-du-tiec-so-vintage-veliana-vay-du-tiec-so-vintage-veliana-1tczsa7','Váy dự tiệc',290000.00,340000.00,350000.00,1969000.00,1300000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:53.000000',NULL,NULL),(42,2,NULL,7,'JOLIE LOFT – VÁY LỤA LUALA DRESS','vay-du-tiec-jolie-loft-vay-lua-luala-dress-vay-du-tiec-jolie-loft-vay-lua-luala-dress-dyy77c','Váy dự tiệc',210000.00,240000.00,330000.00,1890000.00,800000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:53.000000',NULL,NULL),(43,2,NULL,5,'HƯƠNG BOUTIQUE – LOUISE LACE DRESS','vay-du-tiec-huong-boutique-louise-lace-dress-vay-du-tiec-huong-boutique-louise-lace-dress-y2b0ut','Váy dự tiệc',380000.00,420000.00,350000.00,2050000.00,1400000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:53.000000',NULL,NULL),(44,2,NULL,2,'TÚI NHUNG ĐEN D.CHIC','phu-kien-tui-nhung-en-d-chic-phu-kien-tui-nhung-den-dchic-ga4mx8','Phụ kiện',60000.00,80000.00,320000.00,980000.00,300000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:54.000000',NULL,NULL),(45,2,NULL,9,'TÚI DA ĐEN MYS.P','phu-kien-tui-da-en-mys-p-phu-kien-tui-da-den-mysp-1dy6iz','Phụ kiện',70000.00,90000.00,320000.00,590000.00,400000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:54.000000',NULL,NULL),(46,2,NULL,18,'TÚI DA ĐỎ','phu-kien-tui-da-o-phu-kien-tui-da-do-1hprfk3','Phụ kiện',50000.00,70000.00,310000.00,NULL,300000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:54.000000',NULL,NULL),(47,2,NULL,18,'TÚI TRỨNG NGỌC TRAI','phu-kien-tui-trung-ngoc-trai-phu-kien-tui-trung-ngoc-trai-1vjmm0d','Phụ kiện',100000.00,120000.00,330000.00,NULL,400000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:54.000000',NULL,NULL),(48,2,NULL,6,'COMBO PHỤ KIỆN ÁO DÀI (VÒNG + BỜM + TÚI)','phu-kien-combo-phu-kien-ao-dai-vong-bom-tui-phu-kien-com-bo-phu-kien-ao-dai-1gzwtn0','Phụ kiện',80000.00,100000.00,320000.00,NULL,300000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:54.000000',NULL,NULL),(49,2,NULL,6,'COMBO NGỌC TRAI (TÚI + VÒNG CỔ, TÚI + BỜM/VÒNG TAY)','phu-kien-combo-ngoc-trai-tui-vong-co-tui-bom-vong-tay-phu-kien-combo-ngoc-trai-16poe5w','Phụ kiện',80000.00,100000.00,320000.00,NULL,300000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:55.000000',NULL,NULL),(50,2,NULL,18,'TÚI MŨ ĐI BIỂN','phu-kien-tui-mu-i-bien-phu-kien-tui-mu-di-bien-1731mbr','Phụ kiện',80000.00,100000.00,320000.00,500000.00,400000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:55.000000',NULL,NULL),(51,2,NULL,7,'JOLIE LOFT – ĐẦM LỤA KEM HALI DRESS','vay-lua-jolie-loft-am-lua-kem-hali-dress-vay-lua-jolie-loft-dam-lua-kem-hali-dress-1ot7kqt','Váy lụa',175000.00,200000.00,330000.00,1600000.00,600000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:55.000000',NULL,NULL),(52,2,NULL,18,'WONDER HOUSE – LUA DRESS KEM','vay-lua-wonder-house-lua-dress-kem-vay-lua-wonder-house-lua-dress-kem-fiadoc','Váy lụa',165000.00,190000.00,330000.00,795000.00,500000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:55.000000',NULL,NULL),(53,2,NULL,7,'JOLIE LOFT – VÁY LỤA LUALA DRESS','vay-lua-jolie-loft-vay-lua-luala-dress-vay-lua-jolie-loft-vaylua-dress-1o6ik3','Váy lụa',210000.00,240000.00,330000.00,1890000.00,800000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:55.000000',NULL,NULL),(54,2,NULL,7,'JOLIE LOFT – LỤA','vay-lua-jolie-loft-lua-vay-lua-jolie-loft-lua-1ewpzgj','Váy lụa',165000.00,195000.00,330000.00,1320000.00,700000.00,NULL,0.00,0.00,1,'2026-09-09 15:47:55.000000',NULL,NULL);
/*!40000 ALTER TABLE `Products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Refunds`
--

DROP TABLE IF EXISTS `Refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Refunds` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `OrderId` int NOT NULL,
  `PaymentId` int DEFAULT NULL,
  `Type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Amount` decimal(18,2) NOT NULL,
  `Reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountNo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `TransactionCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `RequestedByUserId` int DEFAULT NULL,
  `ProcessedByUserId` int DEFAULT NULL,
  `RequestedAt` datetime(6) NOT NULL,
  `ProcessedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Refunds_OrderId` (`OrderId`),
  KEY `IX_Refunds_PaymentId` (`PaymentId`),
  KEY `IX_Refunds_ProcessedByUserId` (`ProcessedByUserId`),
  KEY `IX_Refunds_RequestedByUserId` (`RequestedByUserId`),
  KEY `IX_Refunds_Status` (`Status`),
  CONSTRAINT `FK_Refunds_Orders_OrderId` FOREIGN KEY (`OrderId`) REFERENCES `Orders` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Refunds_Payments_PaymentId` FOREIGN KEY (`PaymentId`) REFERENCES `Payments` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Refunds_Users_ProcessedByUserId` FOREIGN KEY (`ProcessedByUserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Refunds_Users_RequestedByUserId` FOREIGN KEY (`RequestedByUserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_Refunds_Amount` CHECK ((`Amount` >= 0)),
  CONSTRAINT `CK_Refunds_Status` CHECK ((`Status` in (_utf8mb4'pending',_utf8mb4'processing',_utf8mb4'completed',_utf8mb4'rejected',_utf8mb4'cancelled'))),
  CONSTRAINT `CK_Refunds_Type` CHECK ((`Type` in (_utf8mb4'deposit',_utf8mb4'order_cancel',_utf8mb4'compensation',_utf8mb4'other')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Refunds`
--

LOCK TABLES `Refunds` WRITE;
/*!40000 ALTER TABLE `Refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `Refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `RentalReservations`
--

DROP TABLE IF EXISTS `RentalReservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `RentalReservations` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `OrderItemId` int NOT NULL,
  `ProductInventoryItemId` int NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_RentalReservations_Inventory_Date_Status` (`ProductInventoryItemId`,`StartDate`,`EndDate`,`Status`),
  KEY `IX_RentalReservations_OrderItemId` (`OrderItemId`),
  CONSTRAINT `FK_RentalReservations_OrderItems_OrderItemId` FOREIGN KEY (`OrderItemId`) REFERENCES `OrderItems` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_RentalReservations_ProductInventoryItems_ProductInventoryIte~` FOREIGN KEY (`ProductInventoryItemId`) REFERENCES `ProductInventoryItems` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_RentalReservations_DateRange` CHECK ((`EndDate` > `StartDate`)),
  CONSTRAINT `CK_RentalReservations_Status` CHECK ((`Status` in (_utf8mb4'RESERVED',_utf8mb4'ACTIVE',_utf8mb4'COMPLETED',_utf8mb4'CANCELLED')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `RentalReservations`
--

LOCK TABLES `RentalReservations` WRITE;
/*!40000 ALTER TABLE `RentalReservations` DISABLE KEYS */;
/*!40000 ALTER TABLE `RentalReservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Reviews`
--

DROP TABLE IF EXISTS `Reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Reviews` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `ProductId` int NOT NULL,
  `OrderItemId` int NOT NULL,
  `Rating` int NOT NULL,
  `Comment` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `IsApproved` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Reviews_UserId_OrderItemId` (`UserId`,`OrderItemId`),
  KEY `IX_Reviews_OrderItemId` (`OrderItemId`),
  KEY `IX_Reviews_ProductId_CreatedAt` (`ProductId`,`CreatedAt`),
  KEY `IX_Reviews_UserId` (`UserId`),
  CONSTRAINT `FK_Reviews_OrderItems_OrderItemId` FOREIGN KEY (`OrderItemId`) REFERENCES `OrderItems` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Reviews_Products_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Reviews_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_Reviews_Rating` CHECK ((`Rating` between 1 and 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Reviews`
--

LOCK TABLES `Reviews` WRITE;
/*!40000 ALTER TABLE `Reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `Reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Roles`
--

DROP TABLE IF EXISTS `Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Roles` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Roles_Code` (`Code`),
  UNIQUE KEY `IX_Roles_Name` (`Name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Roles`
--

LOCK TABLES `Roles` WRITE;
/*!40000 ALTER TABLE `Roles` DISABLE KEYS */;
INSERT INTO `Roles` VALUES (1,'CUSTOMER','Customer','Customer who rents fashion products','2026-01-01 00:00:00.000000'),(2,'LENDER','Lender','User who owns and lists rental products','2026-01-01 00:00:00.000000'),(3,'ADMIN','Admin','Platform administrator','2026-01-01 00:00:00.000000');
/*!40000 ALTER TABLE `Roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ShipmentTrackingEvents`
--

DROP TABLE IF EXISTS `ShipmentTrackingEvents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ShipmentTrackingEvents` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ShipmentId` int NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Message` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ProviderEventCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ProviderEventTime` datetime(6) DEFAULT NULL,
  `RawEvent` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `CreatedAt` datetime(6) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_ShipmentTrackingEvents_ShipmentId_CreatedAt` (`ShipmentId`,`CreatedAt`),
  CONSTRAINT `FK_ShipmentTrackingEvents_Shipments_ShipmentId` FOREIGN KEY (`ShipmentId`) REFERENCES `Shipments` (`Id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ShipmentTrackingEvents`
--

LOCK TABLES `ShipmentTrackingEvents` WRITE;
/*!40000 ALTER TABLE `ShipmentTrackingEvents` DISABLE KEYS */;
/*!40000 ALTER TABLE `ShipmentTrackingEvents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Shipments`
--

DROP TABLE IF EXISTS `Shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Shipments` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ShopId` int DEFAULT NULL,
  `OrderId` int NOT NULL,
  `Direction` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Provider` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ServiceType` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TrackingCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `ProviderOrderCode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `SenderName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `SenderPhone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `SenderAddress` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ReceiverName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ReceiverPhone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ReceiverAddress` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ShippingFee` decimal(18,2) NOT NULL,
  `CodAmount` decimal(18,2) NOT NULL,
  `PickupTime` datetime(6) DEFAULT NULL,
  `EstimatedDeliveryTime` datetime(6) DEFAULT NULL,
  `DeliveredAt` datetime(6) DEFAULT NULL,
  `CancelledAt` datetime(6) DEFAULT NULL,
  `RawProviderResponse` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Shipments_Direction` (`Direction`),
  KEY `IX_Shipments_OrderId` (`OrderId`),
  KEY `IX_Shipments_ShopId` (`ShopId`),
  KEY `IX_Shipments_Status` (`Status`),
  KEY `IX_Shipments_TrackingCode` (`TrackingCode`),
  CONSTRAINT `FK_Shipments_Orders_OrderId` FOREIGN KEY (`OrderId`) REFERENCES `Orders` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Shipments_Shops_ShopId` FOREIGN KEY (`ShopId`) REFERENCES `Shops` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_Shipments_CodAmount` CHECK ((`CodAmount` >= 0)),
  CONSTRAINT `CK_Shipments_Direction` CHECK ((`Direction` in (_utf8mb4'outbound',_utf8mb4'return'))),
  CONSTRAINT `CK_Shipments_ShippingFee` CHECK ((`ShippingFee` >= 0)),
  CONSTRAINT `CK_Shipments_Status` CHECK ((`Status` in (_utf8mb4'pending',_utf8mb4'created',_utf8mb4'assigned',_utf8mb4'picked_up',_utf8mb4'shipping',_utf8mb4'delivered',_utf8mb4'failed',_utf8mb4'cancelled',_utf8mb4'returning',_utf8mb4'returned')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Shipments`
--

LOCK TABLES `Shipments` WRITE;
/*!40000 ALTER TABLE `Shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `Shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Shops`
--

DROP TABLE IF EXISTS `Shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Shops` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Address` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Ward` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `District` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `City` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountNo` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `BankAccountName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  `OwnerUserId` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `IX_Shops_IsActive` (`IsActive`),
  KEY `IX_Shops_OwnerUserId` (`OwnerUserId`),
  CONSTRAINT `FK_Shops_Users_OwnerUserId` FOREIGN KEY (`OwnerUserId`) REFERENCES `Users` (`Id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Shops`
--

LOCK TABLES `Shops` WRITE;
/*!40000 ALTER TABLE `Shops` DISABLE KEYS */;
INSERT INTO `Shops` VALUES (2,'Lam Shop','0936413968','lamtranbao1234@gmail.com','Hà Nội',NULL,'Cầu Giấy','Hà Nội',NULL,NULL,NULL,1,'2026-09-08 16:05:33.000000',NULL,11);
/*!40000 ALTER TABLE `Shops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TryOnRequests`
--

DROP TABLE IF EXISTS `TryOnRequests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `TryOnRequests` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int DEFAULT NULL,
  `ProductId` int NOT NULL,
  `RequestId` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `UserImageUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `GarmentImageUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ResultImageUrl` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ErrorMessage` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  `CompletedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_TryOnRequests_RequestId` (`RequestId`),
  KEY `IX_TryOnRequests_ProductId` (`ProductId`),
  KEY `IX_TryOnRequests_Status` (`Status`),
  KEY `IX_TryOnRequests_UserId_CreatedAt` (`UserId`,`CreatedAt`),
  CONSTRAINT `FK_TryOnRequests_Products_ProductId` FOREIGN KEY (`ProductId`) REFERENCES `Products` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_TryOnRequests_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_TryOnRequests_Status` CHECK ((`Status` in (_utf8mb4'pending',_utf8mb4'processing',_utf8mb4'completed',_utf8mb4'failed')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TryOnRequests`
--

LOCK TABLES `TryOnRequests` WRITE;
/*!40000 ALTER TABLE `TryOnRequests` DISABLE KEYS */;
/*!40000 ALTER TABLE `TryOnRequests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserAddresses`
--

DROP TABLE IF EXISTS `UserAddresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserAddresses` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `ReceiverName` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `AddressLine` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Ward` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `District` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `City` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Note` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `IsDefault` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_UserAddresses_UserId` (`UserId`),
  CONSTRAINT `FK_UserAddresses_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserAddresses`
--

LOCK TABLES `UserAddresses` WRITE;
/*!40000 ALTER TABLE `UserAddresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserAddresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserVouchers`
--

DROP TABLE IF EXISTS `UserVouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `UserVouchers` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserId` int NOT NULL,
  `VoucherId` int NOT NULL,
  `Status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `AcquiredAt` datetime(6) NOT NULL,
  `UsedAt` datetime(6) DEFAULT NULL,
  `ExpiresAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_UserVouchers_UserId_Status` (`UserId`,`Status`),
  KEY `IX_UserVouchers_VoucherId` (`VoucherId`),
  CONSTRAINT `FK_UserVouchers_Users_UserId` FOREIGN KEY (`UserId`) REFERENCES `Users` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_UserVouchers_Vouchers_VoucherId` FOREIGN KEY (`VoucherId`) REFERENCES `Vouchers` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_UserVouchers_Status` CHECK ((`Status` in (_utf8mb4'available',_utf8mb4'used',_utf8mb4'expired')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserVouchers`
--

LOCK TABLES `UserVouchers` WRITE;
/*!40000 ALTER TABLE `UserVouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `UserVouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Users` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `RoleId` int NOT NULL,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `PasswordHash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `LoyaltyPoints` int NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Users_Email` (`Email`),
  KEY `IX_Users_RoleId` (`RoleId`),
  CONSTRAINT `FK_Users_Roles_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `Roles` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `CK_Users_LoyaltyPoints` CHECK ((`LoyaltyPoints` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
INSERT INTO `Users` VALUES (1,3,'Admin DoRentMe','admin@dorentme.com','0901234567','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',0,1,'2026-01-01 00:00:00.000000',NULL),(2,2,'Nguyễn Văn An','lender@dorentme.com','0902345678','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',500,1,'2026-01-15 00:00:00.000000',NULL),(3,1,'Trần Thị Bình','customer1@dorentme.com','0903456789','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',250,1,'2026-02-01 00:00:00.000000',NULL),(4,1,'Lê Minh Châu','customer2@dorentme.com','0904567890','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',1200,1,'2026-02-10 00:00:00.000000',NULL),(5,1,'Phạm Thu Hà','customer3@dorentme.com','0905678901','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',800,1,'2026-03-05 00:00:00.000000',NULL),(6,1,'Hoàng Văn Đức','customer4@dorentme.com','0906789012','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',150,1,'2026-03-12 00:00:00.000000',NULL),(7,1,'Đỗ Thanh Hương','customer5@dorentme.com','0907890123','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',2500,1,'2026-03-20 00:00:00.000000',NULL),(8,1,'Vũ Minh Khôi','customer6@dorentme.com','0908901234','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',450,1,'2026-04-01 00:00:00.000000',NULL),(9,1,'Bùi Thị Lan','customer7@dorentme.com','0909012345','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',680,1,'2026-04-15 00:00:00.000000',NULL),(10,1,'Mai Tuấn Minh','customer8@dorentme.com','0910123456','$2a$11$9xKvVqg5hZF3pWXN5h4zHOMqV.BKz7vJNF6JQXxKqE3h5zVxGQYxW',920,1,'2026-05-01 00:00:00.000000',NULL),(11,1,'Trần Bảo Lâm','lamtranbao1234@gmail.com','0936413968','$2a$11$10MrcNAbZKoJDhuzPMOMyO0w4uuWu6eKc9vn7/Ys6gzhGm13aIDPm',0,1,'2026-09-05 09:44:15.668052',NULL),(12,1,'Nguyễn Đức Dương','duongnguyen291105@gmail.com','0394692818','$2a$11$u6josaWpAnOhUJQxbCe3FOahZGi.8VgO0ZC3.aPA16ZL726bFi33y',0,1,'2026-09-11 01:45:44.152858',NULL);
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vouchers`
--

DROP TABLE IF EXISTS `Vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Vouchers` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DiscountType` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `DiscountValue` decimal(18,2) NOT NULL,
  `RequiredPoints` int NOT NULL,
  `MinOrderAmount` decimal(18,2) DEFAULT NULL,
  `StartAt` datetime(6) DEFAULT NULL,
  `EndAt` datetime(6) DEFAULT NULL,
  `UsageLimit` int DEFAULT NULL,
  `UsedCount` int NOT NULL,
  `IsActive` tinyint(1) NOT NULL,
  `CreatedAt` datetime(6) NOT NULL,
  `UpdatedAt` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `IX_Vouchers_Code` (`Code`),
  CONSTRAINT `CK_Vouchers_DateRange` CHECK (((`EndAt` is null) or (`StartAt` is null) or (`EndAt` > `StartAt`))),
  CONSTRAINT `CK_Vouchers_DiscountType` CHECK ((`DiscountType` in (_utf8mb4'fixed',_utf8mb4'percent'))),
  CONSTRAINT `CK_Vouchers_DiscountValue` CHECK ((`DiscountValue` >= 0)),
  CONSTRAINT `CK_Vouchers_MinOrderAmount` CHECK (((`MinOrderAmount` is null) or (`MinOrderAmount` >= 0))),
  CONSTRAINT `CK_Vouchers_RequiredPoints` CHECK ((`RequiredPoints` >= 0)),
  CONSTRAINT `CK_Vouchers_UsageLimit` CHECK (((`UsageLimit` is null) or (`UsageLimit` > 0))),
  CONSTRAINT `CK_Vouchers_UsedCount` CHECK ((`UsedCount` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vouchers`
--

LOCK TABLES `Vouchers` WRITE;
/*!40000 ALTER TABLE `Vouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `Vouchers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `__EFMigrationsHistory`
--

DROP TABLE IF EXISTS `__EFMigrationsHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `__EFMigrationsHistory` (
  `MigrationId` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ProductVersion` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`MigrationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__EFMigrationsHistory`
--

LOCK TABLES `__EFMigrationsHistory` WRITE;
/*!40000 ALTER TABLE `__EFMigrationsHistory` DISABLE KEYS */;
INSERT INTO `__EFMigrationsHistory` VALUES ('20260829142317_InitialCreate','8.0.30'),('20260908154947_ChangeShopSchema','8.0.30'),('20260909010600_ChangeProductSchema','8.0.30'),('20260909065939_UpdateProductCategoryRelationship','8.0.30'),('20260910032115_AddOrderItemRentalSnapshots','8.0.30');
/*!40000 ALTER TABLE `__EFMigrationsHistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dorentme'
--

--
-- Dumping routines for database 'dorentme'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-14  6:05:09
